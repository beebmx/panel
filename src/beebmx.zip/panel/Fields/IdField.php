<?php

namespace Beebmx\Panel\Fields;

use Beebmx\Panel\Fields\BaseField;

class IdField extends BaseField
{
    protected $type = 'id';
    public static $recordable = false;
}
