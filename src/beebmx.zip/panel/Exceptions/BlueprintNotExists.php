<?php
namespace Beebmx\Panel\Exception;

class BlueprintNotExists extends \Exception {}